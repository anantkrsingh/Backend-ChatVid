const express = require("express");
const cors = require("cors");
const http = require("http");
const mongoose = require("mongoose");
const env = require("dotenv");
const bodyParser = require("body-parser");
const socketIO = require("socket.io");
const { Server } = require("socket.io");
const app = express();
const server = http.createServer(app);
const io = socketIO(server);
let users = []

env.config();
const authRoutes = require("./Routes/Auth");
const authRoutesV2 = require("./Routes/AuthV2")
const roomRoutes = require("./Routes/Generator");
const sessionRoutes = require("./Routes/Session");
const { createMeeting } = require("./Controllers/Generator");
const path = require("path");
const { log } = require("console");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


app.use(cors());


const addUser = (userName,roomId)=>{
  users.push({
    userName:userName,
    roomId:roomId
  })
}

const getRoomUsers = (roomId)=>{
  return users.filter(user => (user.roomId === roomId))
}
const userLeave = (userName)=>{
  users = users.filter(user => user.userName != userName)
}

io.on("connection", (socket) => {
  console.log("Client Connected");

  socket.on("disconnect", () => {
    console.log("Client Disconnected");
  });

  socket.on("join-room", ({roomId,userName}) => {
    console.log("User Joined");
    console.log(roomId);
    console.log(userName);
    socket.join(roomId)
    addUser(userName,roomId)
    socket.to(roomId).emit("user-connected",userName)
    io.to(roomId).emit("all-users",getRoomUsers(roomId))
    socket.on("disconnect",()=>{
      console.log("Disconnected");
      socket.leave(roomId);
      userLeave(userName)
      io.to(roomId).emit("all-users",getRoomUsers(roomId))
    })
  });
});




app.use("/api", authRoutes);
app.use("/api/v2/auth", authRoutesV2)
app.use("/api/meeting", roomRoutes);

app.use("/api/session", sessionRoutes);

app.get("/", (req, res) => {
  res.send("<div>Success Response</div>")
});
app.use(express.static(__dirname))


app.use("/html", (req, res) => {
  res.sendFile(path.join(__dirname + '/index.html'))
})

server.listen("4040", "192.168.1.3", () => {
  console.log("Server Started port = 4040");
});

mongoose
  .connect("mongodb://127.0.0.1:27017" + "/ChatVid")
  .then(() => {
    console.log("DB Connected");
  })
  .catch((error) => {
    console.log(error);
  });
